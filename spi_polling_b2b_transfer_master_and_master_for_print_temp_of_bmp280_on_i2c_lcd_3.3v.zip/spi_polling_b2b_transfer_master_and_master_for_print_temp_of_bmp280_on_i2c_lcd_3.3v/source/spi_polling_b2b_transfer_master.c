/*
 * Copyright (c) 2016, Freescale Semiconductor, Inc.
 * Copyright 2016-2017 NXP
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#include "fsl_spi.h"
#include "pin_mux.h"
#include "board.h"
#include "fsl_debug_console.h"

#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include "fsl_i2c.h"
#include "fsl_power.h"
/*******************************************************************************
 * Definitions
 ******************************************************************************/
#define EXAMPLE_SPI_MASTER          SPI7
#define EXAMPLE_SPI_MASTER_IRQ      FLEXCOMM7_IRQn
#define EXAMPLE_SPI_MASTER_CLK_SRC  kCLOCK_Flexcomm7
#define EXAMPLE_SPI_MASTER_CLK_FREQ CLOCK_GetFlexCommClkFreq(7U)
#define EXAMPLE_SPI_SSEL            1
#define EXAMPLE_SPI_SPOL            kSPI_SpolActiveAllLow



#define EXAMPLE_I2C_MASTER_BASE    (I2C1_BASE)
#define I2C_MASTER_CLOCK_FREQUENCY (12000000)
#define WAIT_TIME                  10U
#define EXAMPLE_I2C_MASTER ((I2C_Type *)EXAMPLE_I2C_MASTER_BASE)

#define I2C_MASTER_SLAVE_ADDR_7BIT 0x3EU
#define I2C_BAUDRATE               100000U
#define I2C_DATA_LENGTH            33U


uint8_t g_master_txBuff[I2C_DATA_LENGTH];
uint8_t g_master_rxBuff[I2C_DATA_LENGTH];



uint8_t data_buff[2];
uint8_t *send_data_ptr;


#define I2C_SLAVE_ADDRESS_7BIT         0x3EU
#define LCD_CMD 0x80U
#define LCD_DAT 0x40U
#define LCD_FUN_SET 0X2CU //0X38U //0x28U
#define LCD_DIS_ON_OFF 0x0fU
#define LCD_DIS_CLR 0x01U
#define LCD_ENT_MODE 0x06U
#define LCD_SET_DDRAM_FIRST_ROW 0x80U
#define LCD_SET_DDRAM_SECOND_ROW 0xC0
#define MY_LOOP_SIZE 2

/**************************************************************/

int length = 5;
char s_arr[5] = {'0','0','0','0','0'};
unsigned int s_digit = 22;
float s_data = 12.00;
void digit_to_string_for_print(float input, char *arr, unsigned int number_of_digit)
{
	unsigned int ip_real;
	float ip_float;
	char *temp;
	unsigned int di;
	unsigned int df;
	int ti;
	char tc;
	int loop;


	di = number_of_digit / 10;
	df = number_of_digit % 10;
	temp = arr;
	loop = 0;
	ip_real = input / 1;
	*(temp + di) = '.';

	for(loop = 0; loop < di; loop++)
	{
		ti = ip_real % 10;
		tc = ti + '0';
		ip_real = ip_real / 10;
		*(temp + di - 1 - loop) = tc;
	}

	ip_real = input / 1;
	ip_float = input - ip_real;

	for(loop = 0; loop < df; loop++)
	{
		ip_float = ip_float * 10;
		ti = (int)ip_float % 10;
		tc = ti + '0';
		*(temp + di + 1 + loop) = tc;
		ip_float = ip_float - ti;

	}


}


/*******************************************************************************
 * Prototypes
 ******************************************************************************/

/*******************************************************************************
 * Variables
 ******************************************************************************/
#define BUFFER_SIZE (2)
static uint8_t srcBuff[BUFFER_SIZE];
static uint8_t destBuff[BUFFER_SIZE];

#define TPV_BUFFER_SIZE (4)
static uint8_t srcTPV_Buff[TPV_BUFFER_SIZE];
static uint8_t destTPV_Buff[TPV_BUFFER_SIZE];

#define HD_TX_BUFFER_SIZE (1)
#define HD_RX_BUFFER_SIZE (2)
static uint8_t srcHD_Buff[HD_TX_BUFFER_SIZE];
static uint8_t destHD_Buff[HD_RX_BUFFER_SIZE];

/*****************************************************************/

#define DIG_BUFFER_SIZE (25)
static uint8_t dig_data_src_buff[DIG_BUFFER_SIZE];
static uint8_t dig_data_dest_buff[DIG_BUFFER_SIZE];

float Temperature, Pressure;
int32_t tRaw,pRaw;
int32_t t_fine;

uint16_t dig_T1, dig_P1;

int16_t  dig_T2, dig_T3, dig_P2, dig_P3, dig_P4, dig_P5, dig_P6, dig_P7, dig_P8, dig_P9;

int32_t BME280_compensate_T_int32(int32_t adc_T)
{
	int32_t var1, var2, T;
	var1 = ((((adc_T>>3) - ((int32_t)dig_T1<<1))) * ((int32_t)dig_T2)) >> 11;
	var2 = (((((adc_T>>4) - ((int32_t)dig_T1)) * ((adc_T>>4) - ((int32_t)dig_T1)))>> 12) *((int32_t)dig_T3)) >> 14;
	t_fine = var1 + var2;
	T = (t_fine * 5 + 128) >> 8;
	return T;
}

uint32_t BME280_compensate_P_int32(int32_t adc_P)
{
	int32_t var1, var2;
	uint32_t p;
	var1 = (((int32_t)t_fine)>>1) - (int32_t)64000;
	var2 = (((var1>>2) * (var1>>2)) >> 11 ) * ((int32_t)dig_P6);
	var2 = var2 + ((var1*((int32_t)dig_P5))<<1);
	var2 = (var2>>2)+(((int32_t)dig_P4)<<16);
	var1 = (((dig_P3 * (((var1>>2) * (var1>>2)) >> 13 )) >> 3) + ((((int32_t)dig_P2) *var1)>>1))>>18;
	var1 =((((32768+var1))*((int32_t)dig_P1))>>15);
	if (var1 == 0)
	{
		return 0; // avoid exception caused by division by zero
	}
	p = (((uint32_t)(((int32_t)1048576)-adc_P)-(var2>>12)))*3125;
	if (p < 0x80000000)
	{
		p = (p << 1) / ((uint32_t)var1);
	}
	else
	{
		p = (p / (uint32_t)var1) * 2;
	}
	var1 = (((int32_t)dig_P9) * ((int32_t)(((p>>3) * (p>>3))>>13)))>>12;
	var2 = (((int32_t)(p>>2)) * ((int32_t)dig_P8))>>13;
	p = (uint32_t)((int32_t)p + ((var1 + var2 + dig_P7) >> 4));
	return p;
}


/*******************************************************************************
 * Code
 ******************************************************************************/

int main(void)
{

	send_data_ptr = data_buff;
    i2c_master_config_t masterConfig;
    status_t reVal        = kStatus_Fail;
    uint8_t deviceAddress = 0x7CU;

    spi_master_config_t userConfig = {0};
    uint32_t srcFreq               = 0;
    uint32_t i                     = 0;
    uint32_t err                   = 0;
    spi_transfer_t xfer            = {0};
    status_t spi_ret_status = 0xAAAAAAAA;
    uint32_t spi_buff_data_ret[30] = {0x00};
    uint32_t loop_size = 30;


    spi_half_duplex_transfer_t xferhfd = {0};
    status_t spi_hd_ret_status = 0xAAAAAAAA;

    /* set BOD VBAT level to 1.65V */
    POWER_SetBodVbatLevel(kPOWER_BodVbatLevel1650mv, kPOWER_BodHystLevel50mv, false);
    /* attach 12 MHz clock to FLEXCOMM0 (debug console) */
    CLOCK_AttachClk(BOARD_DEBUG_UART_CLK_ATTACH);

    /* attach 12 MHz clock to FLEXCOMM8 (I2C master) */
    CLOCK_AttachClk(kFRO12M_to_FLEXCOMM1);


    /* attach 12 MHz clock to SPI3 */
    CLOCK_AttachClk(kFRO12M_to_FLEXCOMM7);

    /* reset FLEXCOMM for I2C */
    RESET_PeripheralReset(kFC1_RST_SHIFT_RSTn);

    /* reset FLEXCOMM for SPI */
    RESET_PeripheralReset(kFC7_RST_SHIFT_RSTn);

    BOARD_InitBootPins();
    BOARD_InitBootClocks();
    BOARD_InitDebugConsole();

    I2C_MasterGetDefaultConfig(&masterConfig);

        /* Change the default baudrate configuration */
    masterConfig.baudRate_Bps = I2C_BAUDRATE;

        /* Initialize the I2C master peripheral */
    I2C_MasterInit(EXAMPLE_I2C_MASTER, &masterConfig, I2C_MASTER_CLOCK_FREQUENCY);



    PRINTF("\n\rMaster Start...\n\r");
    /*
     * userConfig.enableLoopback = false;
     * userConfig.enableMaster = true;
     * userConfig.polarity = kSPI_ClockPolarityActiveHigh;
     * userConfig.phase = kSPI_ClockPhaseFirstEdge;
     * userConfig.direction = kSPI_MsbFirst;
     * userConfig.baudRate_Bps = 500000U;
     */
    SPI_MasterGetDefaultConfig(&userConfig);
    srcFreq            = EXAMPLE_SPI_MASTER_CLK_FREQ;
    userConfig.sselNum = (spi_ssel_t)EXAMPLE_SPI_SSEL;
    userConfig.sselPol = (spi_spol_t)EXAMPLE_SPI_SPOL;
    SPI_MasterInit(EXAMPLE_SPI_MASTER, &userConfig, srcFreq);

 /************************************CHIP_ID*************************************/

    /* Init Buffer*/
    for (i = 0; i < BUFFER_SIZE; i++)
    {

        srcBuff[i] = 0xD0;
        destBuff[i] = 0xAA;

    }

    /*Start Transfer*/
    xfer.txData      = srcBuff;
    xfer.rxData      = destBuff;
    xfer.dataSize    = sizeof(destBuff);
    xfer.configFlags = kSPI_FrameAssert;


    spi_ret_status = SPI_MasterTransferBlocking(EXAMPLE_SPI_MASTER, &xfer);


/*******************************CTR_MEAS**************************/

    srcBuff[0] = 0x74;
    srcBuff[1] = 0x26;
    for (i = 0; i < BUFFER_SIZE; i++)
    {

        destBuff[i] = 0xAA;

    }

    spi_ret_status = SPI_MasterTransferBlocking(EXAMPLE_SPI_MASTER, &xfer);

/******************************TEMP******************************/

    srcTPV_Buff[0] = 0xFA;
    srcTPV_Buff[1] = 0xFB;
    srcTPV_Buff[2] = 0xFC;
    srcTPV_Buff[3] = 0xD0;


    for (i = 0; i < TPV_BUFFER_SIZE; i++)
       {

    	destTPV_Buff[i] = 0xAA;

       }

       /*Start Transfer*/
       xfer.txData      = srcTPV_Buff;
       xfer.rxData      = destTPV_Buff;
       xfer.dataSize    = sizeof(destTPV_Buff);
       xfer.configFlags = kSPI_FrameAssert;


       spi_ret_status = SPI_MasterTransferBlocking(EXAMPLE_SPI_MASTER, &xfer);


       tRaw = (destTPV_Buff[1]<<12)|(destTPV_Buff[2]<<4)|(destTPV_Buff[3]>>4);

       for (i = 0; i < DIG_BUFFER_SIZE - 1; i++)
       {

    	   dig_data_src_buff[i] = 0x88 + i;

       }
       dig_data_src_buff[DIG_BUFFER_SIZE - 1] = 0xD0;

       xfer.txData      = dig_data_src_buff;
       xfer.rxData      = dig_data_dest_buff;
       xfer.dataSize    = sizeof(dig_data_dest_buff);
       xfer.configFlags = kSPI_FrameAssert;

       spi_ret_status = SPI_MasterTransferBlocking(EXAMPLE_SPI_MASTER, &xfer);

       dig_T1 = (dig_data_dest_buff[2]<<8) | dig_data_dest_buff[1];
       dig_T2 = (dig_data_dest_buff[4]<<8) | dig_data_dest_buff[3];
       dig_T3 = (dig_data_dest_buff[6]<<8) | dig_data_dest_buff[5];
       dig_P1 = (dig_data_dest_buff[8]<<8) | dig_data_dest_buff[7];
       dig_P2 = (dig_data_dest_buff[10]<<8) | dig_data_dest_buff[9];
       dig_P3 = (dig_data_dest_buff[12]<<8) | dig_data_dest_buff[11];
       dig_P4 = (dig_data_dest_buff[14]<<8) | dig_data_dest_buff[13];
       dig_P5 = (dig_data_dest_buff[16]<<8) | dig_data_dest_buff[15];
       dig_P6 = (dig_data_dest_buff[18]<<8) | dig_data_dest_buff[17];
       dig_P7 = (dig_data_dest_buff[20]<<8) | dig_data_dest_buff[19];
       dig_P8 = (dig_data_dest_buff[22]<<8) | dig_data_dest_buff[21];
       dig_P9 = (dig_data_dest_buff[24]<<8) | dig_data_dest_buff[23];

       Temperature = (BME280_compensate_T_int32(tRaw))/100.0;

/******************************PRESS**********************************************/




       srcTPV_Buff[0] = 0xF7;
       srcTPV_Buff[1] = 0xF8;
       srcTPV_Buff[2] = 0xF9;
       srcTPV_Buff[3] = 0xD0;


       for (i = 0; i < TPV_BUFFER_SIZE; i++)
        {

          destTPV_Buff[i] = 0xAA;

        }

       /*Start Transfer*/
       xfer.txData      = srcTPV_Buff;
       xfer.rxData      = destTPV_Buff;
       xfer.dataSize    = sizeof(destTPV_Buff);
       xfer.configFlags = kSPI_FrameAssert;

       spi_ret_status = SPI_MasterTransferBlocking(EXAMPLE_SPI_MASTER, &xfer);

       pRaw = (destTPV_Buff[1]<<12)|(destTPV_Buff[2]<<4)|(destTPV_Buff[3]>>4);

       Pressure = (BME280_compensate_T_int32(pRaw));

       s_data = Temperature;

       digit_to_string_for_print(s_data, s_arr, s_digit);



       /* Send master blocking data to slave */
       if (kStatus_Success == I2C_MasterStart(EXAMPLE_I2C_MASTER, I2C_SLAVE_ADDRESS_7BIT, kI2C_Write))
       {
           /* subAddress = 0x01, data = g_master_txBuff - write to slave.
             start + slaveaddress(w) + subAddress + length of data buffer + data buffer + stop*/
    	   	   data_buff[0] = LCD_CMD;
    	   	   data_buff[1] = LCD_FUN_SET;
    	   	   reVal = I2C_MasterWriteBlocking(EXAMPLE_I2C_MASTER, send_data_ptr, 2, kI2C_TransferNoStopFlag);
           if (reVal != kStatus_Success)
           {
               return -1;
           }

       	data_buff[0] = LCD_CMD;
       	data_buff[1] = LCD_DIS_ON_OFF;
       	reVal = I2C_MasterWriteBlocking(EXAMPLE_I2C_MASTER, send_data_ptr, 2, kI2C_TransferNoStopFlag);
           if (reVal != kStatus_Success)
           {
               return -1;
           }

       	data_buff[0] = LCD_CMD;
       	data_buff[1] = LCD_DIS_CLR;
       	reVal = I2C_MasterWriteBlocking(EXAMPLE_I2C_MASTER, send_data_ptr, 2, kI2C_TransferNoStopFlag);
           if (reVal != kStatus_Success)
           {
               return -1;
           }

       	data_buff[0] = LCD_CMD;
       	data_buff[1] = LCD_ENT_MODE;
       	reVal = I2C_MasterWriteBlocking(EXAMPLE_I2C_MASTER, send_data_ptr, 2, kI2C_TransferNoStopFlag);
           if (reVal != kStatus_Success)
           {
               return -1;
           }

       	data_buff[0] = LCD_CMD;
       	data_buff[1] = LCD_SET_DDRAM_FIRST_ROW;
       	reVal = I2C_MasterWriteBlocking(EXAMPLE_I2C_MASTER, send_data_ptr, 2, kI2C_TransferNoStopFlag);
           if (reVal != kStatus_Success)
           {
               return -1;
           }

          	data_buff[0] = LCD_DAT;
          	reVal = I2C_MasterWriteBlocking(EXAMPLE_I2C_MASTER, send_data_ptr, 1, kI2C_TransferNoStopFlag);
              if (reVal != kStatus_Success)
              {
                  return -1;
              }


       	reVal = I2C_MasterWriteBlocking(EXAMPLE_I2C_MASTER, s_arr, length, kI2C_TransferNoStopFlag);
           if (reVal != kStatus_Success)
           {
               return -1;
           }




       }


}
